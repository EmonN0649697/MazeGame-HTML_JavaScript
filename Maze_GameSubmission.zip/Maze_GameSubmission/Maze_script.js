var canvas = document.getElementById("Maze");			//Sets canvas variable as per the details in my HTML
var ctx = canvas.getContext("2d");						//Specifies 2D type canvas
var img = document.getElementById("maze_floor2");		//Sets img variable storing my maze floor image from HTML

var Hero = {
    height: 40,					//Setting the attributes of my Hero character
    width: 40,
    x: 10,
    y: 10, 
    color: "#FF0000"        
}

								//Setting the attributes of the 13 walls of the maze

var Wall1 = {
	height: 80,				
	width: 40,
	x: 30,
	y: 90,
	color: "#D2691E"
}

var Wall2 = {
	height: 160,			
	width: 40,
	x: 150,
	y: 0,
	color: "#D2691E"
}

var Wall3 = {
	height: 40,
	width: 190,
	x: 0,
	y: 230,
	color: "#D2691E"
}

var Wall4 = {
	height: 75,
	width: 40,
	x: 80,
	y: 270,
	color: "#D2691E"
}

var Wall5 = {
	height: 40,
	width: 400,
	x: 400,
	y: 130,
	color: "#D2691E"
}

var Wall6 = {
	height: 60,
	width: 40,
	x: 420,
	y: 0,
	color: "#D2691E"
}

var Wall7 = {
	height: 60,
	width: 40,
	x: 530,
	y: 70,
	color: "#D2691E"
}

var Wall8 = {
	height: 70,
	width: 40,
	x: 630,
	y: 0,
	color: "#D2691E"
}

var Wall9 = {
	height: 15,
	width: 70,
	x: 670,
	y: 55,
	color: "#D2691E"
}

var Wall10 = {
	height: 300,
	width: 40,
	x: 270,
	y: 100,
	color: "#D2691E"
}

var Wall11 = {
	height: 40,
	width: 260,
	x: 310,
	y: 230,
	color: "#D2691E"
}

var Wall12 = {
	height: 40,
	width: 110,
	x: 690,
	y: 280,
	color: "#D2691E"
}

var Wall13 = {
	height: 40,
	width: 280,
	x: 410,
	y: 320,
	color: "#D2691E"
}

								//Setting the attributes of the 3 gems

var Gem1 = {
	height: 20,
	width: 20,
	x: 30,
	y: 290,
	color: "#0000FF"
}

var Gem2 = {
	height: 20,
	width: 20,
	x: 690,
	y: 20,
	color: "#0000FF"
}

var Gem3 = {
	height: 20,
	width: 20,
	x: 770,
	y: 240,
	color: "#0000FF"
}

var Gem1Collected = 0;
var Gem2Collected = 0;		//Setting variables for each of the gems to detect whether they have been collected
var Gem3Collected = 0;

var ExitDoor = {			//Setting the attributes of my exit door at the end of the maze

	height: 40,
	width: 20,
	x: 755,
	y: 360,
	color: "#00FF00"
}

var endScreen = document.getElementById("Maze");		//Sets another canvas variable for the purpose of an end screen
var ctx2 = endScreen.getContext('2d');					//Specifies 2D type canvas 
var img2 = document.getElementById("maze_complete");	//Sets another image variable storing my maze_complete image


								//Giving my Hero object movement

document.addEventListener('keydown', function(event) {
    // Gives movement to the left to 10 pixels
    if(event.keyCode == 37) {
        Hero.x -= 10;
    }
    //Gives movement to the top
    else if(event.keyCode == 38) {
        Hero.y -= 10;
    }
    //Gives movement to the right
    else if(event.keyCode == 39) {
        Hero.x += 10;
    }
    //Gives movement to the bottom
    else if(event.keyCode == 40) {
        Hero.y += 10;
    }
	collisioncheck();
});

function renderCanvas(){
	
	ctx.drawImage(img, 0, 0);				//Renders my canvas image from the x and y points specified

} 

function renderHero(){						//Renders my Hero on the canvas
	ctx.fillStyle = "#FF0000";		
    ctx.fillRect(Hero.x, Hero.y, Hero.width, Hero.height);
}

											//Renders my 13 walls on the canvas

function renderWall1(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall1.x, Wall1.y, Wall1.width, Wall1.height);
}

function renderWall2(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall2.x, Wall2.y, Wall2.width, Wall2.height);
}

function renderWall3(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall3.x, Wall3.y, Wall3.width, Wall3.height);
}

function renderWall4(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall4.x, Wall4.y, Wall4.width, Wall4.height);
}

function renderWall5(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall5.x, Wall5.y, Wall5.width, Wall5.height);
}

function renderWall6(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall6.x, Wall6.y, Wall6.width, Wall6.height);
}

function renderWall7(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall7.x, Wall7.y, Wall7.width, Wall7.height);
}

function renderWall8(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall8.x, Wall8.y, Wall8.width, Wall8.height);
}

function renderWall9(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall9.x, Wall9.y, Wall9.width, Wall9.height);
}

function renderWall10(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall10.x, Wall10.y, Wall10.width, Wall10.height);
}

function renderWall11(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall11.x, Wall11.y, Wall11.width, Wall11.height);
}

function renderWall12(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall12.x, Wall12.y, Wall12.width, Wall12.height);
}

function renderWall13(){
    ctx.fillStyle = "#D2691E";
    ctx.fillRect(Wall13.x, Wall13.y, Wall13.width, Wall13.height);
}

											//Renders my 3 Gems on the canvas

function renderGem1(){
    ctx.fillStyle = "#0000FF";
    ctx.fillRect(Gem1.x, Gem1.y, Gem1.width, Gem1.height);
}

function renderGem2(){
    ctx.fillStyle = "#0000FF";
    ctx.fillRect(Gem2.x, Gem2.y, Gem2.width, Gem2.height);
}

function renderGem3(){
    ctx.fillStyle = "#0000FF";
    ctx.fillRect(Gem3.x, Gem3.y, Gem3.width, Gem3.height);
}

function renderExitDoor(){					//Renders my exit door on the canvas
    ctx.fillStyle = "#00FF00";
    ctx.fillRect(ExitDoor.x, ExitDoor.y, ExitDoor.width, ExitDoor.height);
}

								//Runs the action of rendering all my objects with the timer delay set to 0

function run(){
	renderCanvas();
	renderHero();
	renderWall1();
	renderWall2();
	renderWall3();
	renderWall4();
	renderWall5();
	renderWall6();
	renderWall7();
	renderWall8();
	renderWall9();
	renderWall10();
	renderWall11();
	renderWall12();
	renderWall13();
	renderGem1();
	renderGem2();
	renderGem3();
	renderExitDoor();	
}

setInterval(run, 0);

							//All the collision checks for every wall on the canvas

function collisioncheck() {
	if (Wall1.x < Hero.x + Hero.width &&
        Wall1.x + Wall1.width > Hero.x &&
        Wall1.y < Hero.y + Hero.height &&
        Wall1.height + Wall1.y > Hero.y) {
		location.reload();					//Reloads the game if Hero touches the wall
		}
		
	if (Wall2.x < Hero.x + Hero.width &&
        Wall2.x + Wall2.width > Hero.x &&
        Wall2.y < Hero.y + Hero.height &&
        Wall2.height + Wall2.y > Hero.y) {
		location.reload();
		}
		
	if (Wall3.x < Hero.x + Hero.width &&
        Wall3.x + Wall3.width > Hero.x &&
        Wall3.y < Hero.y + Hero.height &&
        Wall3.height + Wall3.y > Hero.y) {
		location.reload();
		}
		
	if (Wall4.x < Hero.x + Hero.width &&
        Wall4.x + Wall4.width > Hero.x &&
        Wall4.y < Hero.y + Hero.height &&
        Wall4.height + Wall4.y > Hero.y) {
		location.reload();
		}
		
	if (Wall5.x < Hero.x + Hero.width &&
        Wall5.x + Wall5.width > Hero.x &&
        Wall5.y < Hero.y + Hero.height &&
        Wall5.height + Wall5.y > Hero.y) {
		location.reload();
		}
		
	if (Wall6.x < Hero.x + Hero.width &&
        Wall6.x + Wall6.width > Hero.x &&
        Wall6.y < Hero.y + Hero.height &&
        Wall6.height + Wall6.y > Hero.y) {
		location.reload();
		}
		
	if (Wall7.x < Hero.x + Hero.width &&
        Wall7.x + Wall7.width > Hero.x &&
        Wall7.y < Hero.y + Hero.height &&
        Wall7.height + Wall7.y > Hero.y) {
		location.reload();
		}
		
	if (Wall8.x < Hero.x + Hero.width &&
        Wall8.x + Wall8.width > Hero.x &&
        Wall8.y < Hero.y + Hero.height &&
        Wall8.height + Wall8.y > Hero.y) {
		location.reload();
		}
		
	if (Wall9.x < Hero.x + Hero.width &&
        Wall9.x + Wall9.width > Hero.x &&
        Wall9.y < Hero.y + Hero.height &&
        Wall9.height + Wall9.y > Hero.y) {
		location.reload();
		}
		
	if (Wall10.x < Hero.x + Hero.width &&
        Wall10.x + Wall10.width > Hero.x &&
        Wall10.y < Hero.y + Hero.height &&
        Wall10.height + Wall10.y > Hero.y) {
		location.reload();
		}
		
	if (Wall11.x < Hero.x + Hero.width &&
        Wall11.x + Wall11.width > Hero.x &&
        Wall11.y < Hero.y + Hero.height &&
        Wall11.height + Wall11.y > Hero.y) {
		location.reload();
		}
		
	if (Wall12.x < Hero.x + Hero.width &&
        Wall12.x + Wall12.width > Hero.x &&
        Wall12.y < Hero.y + Hero.height &&
        Wall12.height + Wall12.y > Hero.y) {
		location.reload();
		}
		
	if (Wall13.x < Hero.x + Hero.width &&
        Wall13.x + Wall13.width > Hero.x &&
        Wall13.y < Hero.y + Hero.height &&
        Wall13.height + Wall13.y > Hero.y) {
		location.reload();
		}

									//All the collision checks for every Gem on the canvas
	
	if (Gem1.x < Hero.x + Hero.width &&
        Gem1.x + Gem1.width > Hero.x &&
        Gem1.y < Hero.y + Hero.height &&
        Gem1.height + Gem1.y > Hero.y) {
		Gem1Collected +=1,					//Lets the program know that this Gem has been collected
		alert("Nice one! You've now replaced the Gem with a fake, keep going!");

		}
		else if (Gem1Collected >= 2) {
				
					alert("Oh wait hang on, you've just taken back the fake gem and set off the pressure trap!"),
					location.reload();		//Reloads game if player attempts to get the same Gem again
					}
		
		
	if (Gem2.x < Hero.x + Hero.width &&
        Gem2.x + Gem2.width > Hero.x &&
        Gem2.y < Hero.y + Hero.height &&
        Gem2.height + Gem2.y > Hero.y) {
		Gem2Collected +=1,
		alert("Great work! You've replaced this Gem with a fake, carry on!");
		}
		else if (Gem2Collected >= 2) {
			
					alert("Oh wait hang on, you've just taken back the fake gem and set off the pressure trap!"),
					location.reload();
					}
		
		
	if (Gem3.x < Hero.x + Hero.width &&
        Gem3.x + Gem3.width > Hero.x &&
        Gem3.y < Hero.y + Hero.height &&
        Gem3.height + Gem3.y > Hero.y) {
		Gem3Collected +=1,
		alert("Fantastic! A fake gem will take its place, make it to the exit!");
		}
		else if (Gem3Collected >= 2) {
			
					alert("Oh wait hang on, you've just taken back the fake gem and set off the pressure trap!"),
					location.reload();
					}
		
										//Collision checks for the exit door

	if (ExitDoor.x < Hero.x + Hero.width &&
        ExitDoor.x + ExitDoor.width > Hero.x &&
        ExitDoor.y < Hero.y + Hero.height &&
        ExitDoor.height + ExitDoor.y > Hero.y &&
		
		Gem1Collected ==1 && Gem2Collected ==1 && Gem3Collected ==1) {		
		alert ("Door unlocked! You've reached the end! Run free with your riches, friend! The Maze is complete!")
		function renderendScreen(){
			ctx2.drawImage(img2, 0, 0);  //Another rendering function to draw my end screen image to the screen only if the above conditions are met
			}	
		function run(){
			renderendScreen();
		}
		setInterval (run, 0);		
		}
		
		else if (ExitDoor.x < Hero.x + Hero.width &&
				ExitDoor.x + ExitDoor.width > Hero.x &&
				ExitDoor.y < Hero.y + Hero.height &&
				ExitDoor.height + ExitDoor.y > Hero.y &&
		
				Gem1Collected < 1 && Gem2Collected < 1 && Gem3Collected < 1) {
				alert("I think you're short of a few Gems there, friend...")
				location.reload()		//If Hero advances to the exit door before having collected all the Gems, the game reloads
				}
	
}


